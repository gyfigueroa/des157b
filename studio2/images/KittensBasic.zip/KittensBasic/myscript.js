$(window).load(function(){
    $('.flexslider').flexslider(
        {
            animation: "slide",
            slideshowSpeed: 2000,
            direction: "vertical",
            revserse: true,
            pauseOnHover: true
        }
    );
});
